rootProject.extra.apply {
    set("androidPlugin", "com.android.tools.build:gradle:7.0.2")
    set("kotlinVersion", "1.5.30")
}

repositories {
    google()
    jcenter()
}
